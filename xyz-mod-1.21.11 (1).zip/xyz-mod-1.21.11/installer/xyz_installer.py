import os, shutil, subprocess, webbrowser
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

MC = os.path.join(os.environ.get("APPDATA", ""), ".minecraft")
MODS = os.path.join(MC, "mods")

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("XYZ Installer")
        self.geometry("460x260")
        self.jar = tk.StringVar()
        tabs = ttk.Notebook(self); tabs.pack(fill="both", expand=True)

        f1 = ttk.Frame(tabs); tabs.add(f1, text="Install")
        ttk.Label(f1, text="Plik moda XYZ (.jar):").pack(pady=(15, 3))
        ttk.Entry(f1, textvariable=self.jar, width=55).pack()
        ttk.Button(f1, text="Wybierz...", command=self.pick).pack(pady=5)
        ttk.Button(f1, text="Zainstaluj do mods", command=self.install).pack(pady=5)
        ttk.Button(f1, text="Otworz folder mods", command=self.open_mods).pack()

        f2 = ttk.Frame(tabs); tabs.add(f2, text="Launch")
        ttk.Label(f2, text="Wymagane: Fabric Loader + Fabric API (1.21.11)").pack(pady=15)
        ttk.Button(f2, text="Pobierz Fabric", command=lambda: webbrowser.open("https://fabricmc.net/use/installer/")).pack(pady=4)
        ttk.Button(f2, text="Uruchom Minecraft Launcher", command=self.launch).pack(pady=4)

    def pick(self):
        p = filedialog.askopenfilename(filetypes=[("JAR", "*.jar")])
        if p: self.jar.set(p)

    def install(self):
        if not os.path.isfile(self.jar.get()):
            return messagebox.showerror("Blad", "Wybierz plik .jar")
        os.makedirs(MODS, exist_ok=True)
        shutil.copy(self.jar.get(), MODS)
        messagebox.showinfo("OK", "Zainstalowano w:\n" + MODS)

    def open_mods(self):
        os.makedirs(MODS, exist_ok=True); os.startfile(MODS)

    def launch(self):
        for exe in (r"C:\Program Files (x86)\Minecraft Launcher\MinecraftLauncher.exe",
                    r"C:\Program Files\Minecraft Launcher\MinecraftLauncher.exe"):
            if os.path.exists(exe):
                return subprocess.Popen([exe])
        messagebox.showwarning("Brak", "Nie znaleziono launchera, odpal go recznie.")

App().mainloop()
