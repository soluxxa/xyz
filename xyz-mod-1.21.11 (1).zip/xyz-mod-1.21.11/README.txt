XYZ - Fabric 1.21.11 (pelny projekt Gradle)

Opcja A - lokalnie (JDK 21 + Gradle 9.2.1):
  gradle build   -> build/libs/xyz-1.0.0.jar

Opcja B - bez instalowania czegokolwiek:
  1. Wrzuc caly folder na swoje repozytorium GitHub.
  2. Zakladka Actions -> build -> pobierz artefakt "xyz-jar".

Instalacja: installer/xyz_installer.py (wybierz jar -> Zainstaluj).
W grze: Right Shift = menu. Wymagane: Fabric Loader + Fabric API 1.21.11.

Wersje w gradle.properties moga sie zdezaktualizowac. Jesli Gradle zglosi, ze
jakiejs wersji nie ma, wez aktualne z https://fabricmc.net/develop.
Moduly dzialaja tylko w singleplayerze / swiecie hostowanym lokalnie.
