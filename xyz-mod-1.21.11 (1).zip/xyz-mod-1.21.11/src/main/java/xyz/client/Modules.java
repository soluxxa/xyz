package xyz.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.Vec3d;

import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.List;

public final class Modules {
    public static final Module FLY = new Module("Fly") {
        @Override public void tick(MinecraftClient mc) {
            mc.player.getAbilities().allowFlying = true;
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) {
                mc.player.getAbilities().allowFlying = false;
                mc.player.getAbilities().flying = false;
            }
        }
    };

    public static final Module SPEED = new Module("Speed") {
        @Override public void tick(MinecraftClient mc) {
            if (mc.player.isOnGround() && mc.options.forwardKey.isPressed()) {
                Vec3d v = mc.player.getVelocity();
                double h = Math.hypot(v.x, v.z);
                if (h > 0 && h < 0.35) {
                    mc.player.setVelocity(v.x * 1.15, v.y, v.z * 1.15);
                }
            }
        }
    };

    public static final Module AUTO_SPRINT = new Module("AutoSprint") {
        @Override public void tick(MinecraftClient mc) {
            if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision) {
                mc.player.setSprinting(true);
            }
        }
    };

    public static final Module NIGHT_VISION = new Module("NightVision") {
        @Override public void tick(MinecraftClient mc) {
            mc.player.addStatusEffect(new StatusEffectInstance(
                StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    };

    public static final Module AUTO_MINE = new Module("AutoMine") {
        private int cooldown;

        @Override public void tick(MinecraftClient mc) {
            if (MineConfig.TARGETS.isEmpty() || mc.world == null) return;
            if (--cooldown > 0) return;
            MinecraftServer server = mc.getServer();
            if (server == null) return;

            BlockPos origin = mc.player.getBlockPos();
            int r = MineConfig.range;
            for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
            for (int dz = -r; dz <= r; dz++) {
                BlockPos pos = origin.add(dx, dy, dz);
                String id = Registries.BLOCK.getId(mc.world.getBlockState(pos).getBlock()).toString();
                if (MineConfig.TARGETS.contains(id)) {
                    var uuid = mc.player.getUuid();
                    var key = mc.world.getRegistryKey();
                    server.execute(() -> {
                        ServerWorld sw = server.getWorld(key);
                        ServerPlayerEntity sp = server.getPlayerManager().getPlayer(uuid);
                        if (sw != null && sp != null) sw.breakBlock(pos, true, sp);
                    });
                    cooldown = MineConfig.delayTicks;
                    return;
                }
            }
        }
    };

    public static final List<Module> ALL = List.of(FLY, SPEED, AUTO_SPRINT, NIGHT_VISION, AUTO_MINE);

    private Modules() {}

    public static void disableAll() {
        for (Module m : ALL) if (m.enabled) m.toggle();
    }
}
