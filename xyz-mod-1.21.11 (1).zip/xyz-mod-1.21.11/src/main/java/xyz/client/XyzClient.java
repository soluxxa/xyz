package xyz.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class XyzClient implements ClientModInitializer {
    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        // W 1.21.9+ kategorie klawiszy to obiekt (KeyBinding.Category)
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("xyz", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.xyz.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));

        MineConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new XyzScreen());
        }

        // Moduly dzialaja wylacznie w singleplayerze / swiecie hostowanym lokalnie
        if (mc.player == null || !mc.isInSingleplayer()) {
            Modules.disableAll();
            return;
        }
        for (Module m : Modules.ALL) if (m.enabled) m.tick(mc);
    }
}
