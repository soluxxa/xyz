package xyz.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class XyzScreen extends Screen {
    public XyzScreen() { super(Text.literal("XYZ")); }

    private static Text label(Module m) {
        return Text.literal(m.name + ": " + (m.enabled ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int w = 160, h = 20, x = width / 2 - w / 2, y = height / 2 - 50;
        for (Module m : Modules.ALL) {
            addDrawableChild(ButtonWidget.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).dimensions(x, y, w, h).build());
            y += 24;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("AutoMine: ustaw bloki..."),
            b -> client.setScreen(new MineScreen())).dimensions(x, y, w, h).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("XYZ (tylko singleplayer / wlasny swiat)"),
            width / 2, height / 2 - 75, 0xFFFFFF);
    }
}
