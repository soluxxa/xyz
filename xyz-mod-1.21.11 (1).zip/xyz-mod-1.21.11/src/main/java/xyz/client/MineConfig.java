package xyz.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

public final class MineConfig {
    public static final Set<String> TARGETS = new LinkedHashSet<>();
    public static int range = 4;
    public static int delayTicks = 4;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("xyz-automine.txt");
    }

    public static void load() {
        try {
            if (Files.exists(file())) {
                TARGETS.clear();
                for (String l : Files.readAllLines(file())) if (!l.isBlank()) TARGETS.add(l.trim());
            }
        } catch (IOException ignored) {}
    }

    public static void save() {
        try { Files.write(file(), TARGETS); } catch (IOException ignored) {}
    }

    /** "diamond_ore" -> "minecraft:diamond_ore" */
    public static String normalize(String s) {
        s = s.trim().toLowerCase();
        return s.contains(":") ? s : "minecraft:" + s;
    }
}
