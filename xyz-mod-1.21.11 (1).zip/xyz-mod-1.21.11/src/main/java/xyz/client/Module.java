package xyz.client;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public boolean enabled;

    protected Module(String name) { this.name = name; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public abstract void tick(MinecraftClient mc);
}
