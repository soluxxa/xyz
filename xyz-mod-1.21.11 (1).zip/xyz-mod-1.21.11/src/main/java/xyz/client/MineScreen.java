package xyz.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.ArrayList;

public class MineScreen extends Screen {
    private TextFieldWidget input;

    public MineScreen() { super(Text.literal("AutoMine - bloki")); }

    @Override
    protected void init() {
        int cx = width / 2;
        input = new TextFieldWidget(textRenderer, cx - 100, 30, 130, 20, Text.literal("id bloku"));
        input.setPlaceholder(Text.literal("np. diamond_ore"));
        addDrawableChild(input);

        addDrawableChild(ButtonWidget.builder(Text.literal("Dodaj"), b -> {
            if (!input.getText().isBlank()) {
                MineConfig.TARGETS.add(MineConfig.normalize(input.getText()));
                MineConfig.save(); input.setText(""); rebuild();
            }
        }).dimensions(cx + 35, 30, 65, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Dodaj blok, na ktory patrze"), b -> {
            HitResult hit = client.crosshairTarget;
            if (hit instanceof BlockHitResult bh && client.world != null) {
                var block = client.world.getBlockState(bh.getBlockPos()).getBlock();
                MineConfig.TARGETS.add(Registries.BLOCK.getId(block).toString());
                MineConfig.save(); rebuild();
            }
        }).dimensions(cx - 100, 54, 200, 20).build());

        int y = 82;
        for (String id : new ArrayList<>(MineConfig.TARGETS)) {
            if (y > height - 30) break;
            addDrawableChild(ButtonWidget.builder(Text.literal("X  " + id), b -> {
                MineConfig.TARGETS.remove(id); MineConfig.save(); rebuild();
            }).dimensions(cx - 100, y, 200, 18).build());
            y += 20;
        }
    }

    private void rebuild() { clearAndInit(); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Co ma kopac AutoMine (klik = usun)"), width / 2, 12, 0xFFFFFF);
    }
}
